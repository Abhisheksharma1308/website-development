# 🏠 Bestocity Realtors — Website + CRM

A complete, production-ready real estate consultancy website for **Bestocity Realtors**, serving Delhi NCR and Goa markets. Built with pure HTML, CSS, and JavaScript — no frameworks, no dependencies, GitHub-ready.

---

## 📁 Project Structure

```
bestocity/
├── index.html          → Home Page
├── services.html       → Services Page
├── about.html          → About Us Page
├── contact.html        → Contact Page
├── crm.html            → CRM Dashboard
├── css/
│   └── style.css       → All styles (responsive, dark/light)
├── js/
│   ├── main.js         → Core JS (nav, scroll, counter, form)
│   └── crm.js          → CRM system (leads, pipeline, reports)
├── assets/             → Place images/icons here
└── README.md
```

---

## 🚀 Features

### Website
- ✅ **5-page website** — Home, Services, About Us, Contact, CRM
- ✅ **Luxury aesthetic** — Navy & Gold, Cormorant Garamond typography
- ✅ **Fully responsive** — Mobile, tablet, desktop
- ✅ **Animated hero** — Counter stats, floating property cards
- ✅ **Scroll reveal** — Smooth element animations on scroll
- ✅ **Interactive FAQ** — Accordion on Contact page
- ✅ **Fixed navbar** — Shrinks on scroll, mobile hamburger menu
- ✅ **Contact form** — With success feedback

### CRM (Lead Management System)
- ✅ **Dashboard** — Stats, recent leads, activity feed, lead sources
- ✅ **All Leads** — Full table with search, filter, sort
- ✅ **Pipeline View** — Kanban-style deal pipeline
- ✅ **Reports** — Conversion rates, city-wise breakdown, charts
- ✅ **Add / Edit / Delete Leads**
- ✅ **Lead Detail Modal** — Full lead view with call button
- ✅ **CSV Export** — One-click lead export
- ✅ **LocalStorage** — Data persists in browser between sessions
- ✅ **Sample data** — 10 pre-loaded leads to get started

---

## 🛠️ Setup & Usage

### Option 1 — Open Directly
Just open `index.html` in any browser. No server or build step needed.

### Option 2 — Local Server (Recommended)
```bash
# Python
python -m http.server 8000

# Node.js (npx)
npx serve .

# VS Code
Install "Live Server" extension → Right-click index.html → Open with Live Server
```

### Option 3 — GitHub Pages
1. Push this repo to GitHub
2. Go to **Settings → Pages**
3. Source: `main` branch, `/ (root)` folder
4. Your site will be live at `https://yourusername.github.io/bestocity/`

---

## ✏️ Customisation Guide

### 1. Company Details
Search and replace across all HTML files:
| Placeholder | Replace With |
|---|---|
| `Bestocity Realtors` | Your company name |
| `info@bestocity.com` | Your email |
| `+91 9X XXXX XXXX` | Your phone number |
| `Sector 18, Noida` | Your NCR office address |
| `Candolim Beach Road` | Your Goa office address |

### 2. Colors (css/style.css)
Edit the CSS variables at the top of `style.css`:
```css
:root {
  --navy:  #0B1B2B;   /* Primary dark color */
  --gold:  #C9A84C;   /* Accent color */
  --cream: #F7F3ED;   /* Background */
}
```

### 3. CRM Sample Data (js/crm.js)
Replace the `leads` array with your own data, or clear it and add leads via the UI. Data is saved to `localStorage` automatically.

### 4. Adding Real Property Images
Replace the emoji placeholders in HTML with `<img>` tags:
```html
<!-- Replace this -->
<div class="prop-img-placeholder">🏙️</div>

<!-- With this -->
<img src="assets/property-name.jpg" alt="Property Name" style="width:100%;height:180px;object-fit:cover;border-radius:8px">
```

### 5. Google Maps (contact.html)
Replace the map placeholder section with:
```html
<iframe 
  src="https://www.google.com/maps/embed?pb=YOUR_EMBED_URL"
  width="100%" height="280" style="border:0" allowfullscreen loading="lazy">
</iframe>
```

### 6. WhatsApp Button
Add a floating WhatsApp button by inserting before `</body>`:
```html
<a href="https://wa.me/91XXXXXXXXXX?text=Hi, I'm interested in a property" 
   style="position:fixed;bottom:2rem;right:2rem;background:#25d366;color:white;
          width:56px;height:56px;border-radius:50%;display:flex;align-items:center;
          justify-content:center;font-size:1.6rem;box-shadow:0 4px 20px rgba(0,0,0,0.2);
          z-index:999;text-decoration:none;">💬</a>
```

---

## 📦 GitHub Repository Setup

```bash
# 1. Initialize git
git init

# 2. Add all files
git add .

# 3. First commit
git commit -m "Initial commit: Bestocity Realtors website + CRM"

# 4. Add remote (replace with your repo URL)
git remote add origin https://github.com/yourusername/bestocity-realtors.git

# 5. Push
git push -u origin main
```

---

## 🧩 Tech Stack
- **HTML5** — Semantic markup
- **CSS3** — Custom properties, Grid, Flexbox, animations
- **Vanilla JS** — No frameworks, no build tools
- **Google Fonts** — Cormorant Garamond + DM Sans
- **LocalStorage** — CRM data persistence

---

## 📄 License
© 2024 Bestocity Realtors. All rights reserved.

---

*Built for Bestocity Realtors — Delhi NCR & Goa*
